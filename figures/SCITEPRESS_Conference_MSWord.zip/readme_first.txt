The template (example) and the FormatContentsForAUthors provided are for the MSWord camera-ready format to SCITEPRESS Proceedings.


